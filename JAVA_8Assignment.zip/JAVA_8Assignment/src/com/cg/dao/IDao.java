package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.beans.Datafile;

public interface IDao {
	
	public void compareDatafiles(ArrayList<Datafile> xlist, ArrayList<Datafile> ylist) throws Exception;
	public List<Datafile> getList();
	public StringBuilder getExactMatch();
	public StringBuilder getWeakMatch();
	public StringBuilder getXBreak();
        public StringBuilder getYBreak();
	
}
