package com.cg.validate;

public class Validation {
	public boolean validateAccountId(String accId) {
		 String regex="^[0-9]{7}[A-Z]{4}$";
		 return accId.matches(regex);	
	}

	public boolean validateAccountName(String accName) {
		String regex="^[a-zA-Z]*$";
                return accName.matches(regex);
	}

	

}
