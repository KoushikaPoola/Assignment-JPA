package com.cg.user;

import java.util.Scanner;
import com.cg.beans.Account;
import com.cg.beans.Loan;
import com.cg.beans.Transaction;
import com.cg.dao.IDao;
import com.cg.dao.DaoImp;
import com.cg.validate.Validation;


public class Main {
    public static void main( String[] args ){
                String accname, accid, address, loanId, loanType;
		double deposit, withdraw, loanAmount;
		
		IDao dao = new DaoImp();
		Validation validate = new Validation();
		Transaction transaction = new Transaction();


		while (true) {
			
			System.out.println("Enter-1. for Create Account");
			System.out.println("Enter-2. for Deposit Amount");
			System.out.println("Enter-3. for Withdraw Amount");
			System.out.println("Enter-4. for Applying Loan");
			System.out.println("Enter-5. for Account Details");
			System.out.println("Enter-6. for Pay Loan");
			System.out.println("Enter-7. for Loan Details");
			System.out.println("Enter-8. for Exit");

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your choice...");
			int choice = sc.nextInt();
                        switch (choice) 
			{
			case 1: //create account
			{
				while (true) 
				{
					
					System.out.println("Enter your Name (First letter in UpperCase)");
					accname = sc.next();
					if (validate.validateAccountName(accname)) 
					{
						System.out.println("Enter your Account Id (eg. 1234567-ADEF)");
						accid = sc.next();
						if (validate.validateAccountId(accid))
						{
							System.out.println("Enter your Address:");
							address = sc.next();
							System.out.println("Enter Deposit Amount:");
							deposit = sc.nextDouble();
							Account acc = new Account(accid, accname, address, deposit);
							dao.createAccount(acc);
							break;
						} else 
						{
							System.out.println("Please enter valid accountId");
						}
					} else
						System.out.println("Please enter valid accountname");
				}
				break;
			}
				
			case 2: //deposit amount
			{
				
				System.out.println("Enter your Account Id and DepositAmount");
				accid = sc.next();
				deposit = sc.nextDouble();
				double newbal=dao.deposit(accid,deposit);
				System.out.println("Updated balance :"+newbal);
				break;
			}
			
		
			case 3: //withdraw amount
			{
				System.out.println("Enter your Account Id and WithdrawAmount");
				accid = sc.next();
				withdraw = sc.nextDouble();
                                double bal=dao.withdraw(accid,withdraw);
				System.out.println("Updated balance after withdrawl is: " +bal);
				break;
			}
			
			case 4: //applying loan
			{
				System.out.println("Enter your Account Id:");
				accid = sc.next();
				System.out.println("Enter your Loan Id:");
				loanId = sc.next();
				if (accid.equals(loanId)) {
					System.out.println("Select Loan Type :(Car/Home/Education)");
					loanType = sc.next();
					System.out.println("Enter loan amount:");
					loanAmount = sc.nextDouble();
					Loan l = new Loan(loanId, loanType, loanAmount);
					dao.applyLoan(l);
					break;
				} else
					System.out.println("Enter valid Loan Id...");
				break;
			}
			
			case 5: //account details
			{
				System.out.println("Enter your Account Id:");
                                accId = sc.next();
                                Account acc =dao.getAccDetails(accId);
                                if(acc!=null) {
			              System.out.println(acc);
			        }else {
				     System.out.println("No records found");
			        }
				break;
                        }
			case 6: //pay loan
			{
				System.out.println("Enter your  accountId:");
				accid = sc.next();
				System.out.println("Enter Loan Id");
				loanId = sc.next();
				System.out.println("Enter amount to repay:");
				loanAmount = sc.nextDouble();
				double bal1 = dao.payLoan(accid, loanAmount);
				System.out.println("Repaid loan amount "+bal1);
				break;
			}
			
			case 7: //loan details
			{
				System.out.println("Enter loan Id:");
				Loan loan =dao.getLoanDetails(sc.next());
				loanId = sc.next();
				break;

			}
			case 8: 
			{
				System.exit(0);
			}
			default:
				System.out.println("Thankyou....");
			}
		}
    }
}
