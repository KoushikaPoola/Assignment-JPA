package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Servicedb {
	private static EntityManagerFactory emf; 
	private static EntityManager emt;
        static{
		emf= Persistence.createEntityManagerFactory("demo");
	}
	public EntityManager getManager() {
		if(emt==null || !emt.isOpen()){
                     emt=emf.createEntityManager();
                }
		else
                     getManager();
		   return emt;
	}

}
