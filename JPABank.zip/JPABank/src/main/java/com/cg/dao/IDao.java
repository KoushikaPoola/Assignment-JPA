package com.cg.dao;

import java.util.List;
import com.cg.beans.Account;
import com.cg.beans.Loan;
import com.cg.beans.Transaction;

public interface IDao {
	
	public void createAccount(Account acc);
	public Account getAccDetails(String accId);
	public void getLoan(Loan l);
	public Loan getLoanDetails(String loanId);
	public double deposit(String accId, double depositAmount);
	public double withdraw(String accId, double withdraw);
        public double payLoan(String id, double amt);
}
