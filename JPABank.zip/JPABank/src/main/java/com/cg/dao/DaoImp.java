package com.cg.dao;

import java.util.Iterator;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.beans.Account;
import com.cg.beans.Loan;
import com.cg.beans.Transaction;
import com.cg.dao.IDao;
import com.cg.service.Servicedb;

public class DaoImp implements IDao {
	       Servicedb conn;
	       EntityManager em;

	public DaoImp(){
		conn=new Servicedb();
		em= conn.getManager();
	}

        public void createAccount(Account acc) {
		em.getTransaction().begin();
		em.persist(acc);
		em.flush();
		em.getTransaction().commit();
		System.out.println("Your account is created successfully...");
	}

        public Account getAccDetails(String accId) {
		em.getTransaction().begin();
		Query qr = em.createQuery("select acc from Account acc where acc.accountId=?1",Account.class);
		qr.setParameter(1,accId);
		List temp = qr.getResultList();
		if(temp.size()!=0){
		Iterator iterat=temp.iterator();
		while(iterat.hasNext()){
			Account ac=(Account)iterat.next();
			System.out.println("Your account details are :");
			System.out.println("Account_id : "+ac.getAccountId());
			System.out.println("Account_Name : "+ac.getAccountName());
			System.out.println("Address : "+ac.getAddress());
			System.out.println("Account Deposit : "+ac.getDepositAmount());
		}
		}
		else{
		System.out.println("No such records found !");
		}
		em.getTransaction().commit();
		return null;	
	}

	public void getLoan(Loan l) {
		em.getTransaction().begin();
		em.persist(l);
		em.flush();
		em.getTransaction().commit();
		System.out.println("Your loan is created successfully...");
	}

	public Loan getLoanDetails(String loanId) {
		em.getTransaction().begin();
		Query qr = em.createQuery("select l from Loan l where l.loanId=?1",Loan.class);
		qr.setParameter(1,loanId);
		List temp = qr.getResultList();
		if(temp.size()!=0){
		Iterator iterat=temp.iterator();
		while(iterat.hasNext()){
			Loan loan=(Loan)iterat.next();
			System.out.println("Your loan details are :");
			System.out.println("Loan_id : "+loan.getLoanId());
			System.out.println("Loan_Name : "+loan.getLoanType());
			System.out.println("Loan_Amount : "+loan.getLoanAmount());
		}
		}
		else{
		System.out.println("No such records found !");
		}
		em.getTransaction().commit();
		return null;
		
	}
	
        public double deposit(String accId, double depositAmount) {
	em.getTransaction().begin();
	TypedQuery<Account> q = em.createQuery("select acc from Account acc where acc.accountId= ?1", Account.class);
	q.setParameter(1,accId);
        double newBal= q.getSingleResult().getDepositAmount();
        TypedQuery<Account> ql = (TypedQuery<Account>) em.createQuery("update Account acc set acc.depositAmount = ?1 where acc.accountId= ?2");
        ql.setParameter(1, newBal+depositAmount);
        ql.setParameter(2, accId);
        int i=ql.executeUpdate();
        em.getTransaction().commit();
         if(i>0){
		return newBal+depositAmount;
	        return -1;
         }
	}

	public double withdraw(String accId, double withdraw)  {
	em.getTransaction().begin();
	TypedQuery<Account> q = em.createQuery("select ac from Account ac where ac.accountId= ?1",Account.class);
	q.setParameter(1,accId);
        double newBal= q.getSingleResult().getDepositAmount();
        TypedQuery<Account> ql = (TypedQuery<Account>) em.createQuery("update Account ac set ac.depositAmount = ?1 where ac.accountId= ?2");
        ql.setParameter(1, newBal-withdraw);
        ql.setParameter(2, accId);
        int i=ql.executeUpdate();
        em.getTransaction().commit();
         if(i>0){
		return newBal-withdraw;
	        return -1;
         }
	}

        public double payLoan(String id, double amt)  {
	em.getTransaction().begin();
        TypedQuery<Account> q = (TypedQuery<Account>) em.createQuery("select ac from Account ac where ac.loanId= ?1");
	q.setParameter(1,id);
        double newBal= ((Loan) q.getSingleResult()).getLoanAmount();
        TypedQuery<Loan> ql = (TypedQuery<Loan>) em.createQuery("update Account ac set ac.loanAmount = ?1 where ac.loanId= ?2");
        ql.setParameter(1, newBal-amt);
        ql.setParameter(2, id);
        int i=ql.executeUpdate();
        em.getTransaction().commit();
         if(i>0){
		return newBal-amt;
	        return -1;
          }
        }
}